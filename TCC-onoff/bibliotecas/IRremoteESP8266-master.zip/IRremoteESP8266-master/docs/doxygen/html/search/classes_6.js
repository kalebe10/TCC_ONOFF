var searchData=
[
  ['magiquest_3812',['magiquest',['../unionmagiquest.html',1,'']]],
  ['match_5fresult_5ft_3813',['match_result_t',['../structmatch__result__t.html',1,'']]],
  ['mideaprotocol_3814',['MideaProtocol',['../unionMideaProtocol.html',1,'']]]
];
